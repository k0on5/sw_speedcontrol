config = {
    ["permission"] = "police.basic"
}